/**
 * AutoNav — Navigation automatique multi-pages
 * Persiste l'état via localStorage entre les pages
 */

const AN = {
  PAGES: [
    { file: 'index.html',    name: 'Accueil'   },
    { file: 'vision.html',   name: 'Vision'    },
    { file: 'services.html', name: 'Services'  },
    { file: 'stats.html',    name: 'Chiffres'  },
    { file: 'histoire.html', name: 'Histoire'  },
    { file: 'projets.html',  name: 'Projets'   },
    { file: 'equipe.html',   name: 'Équipe'    },
    { file: 'contact.html',  name: 'Contact'   },
  ],

  BASE_PAUSE: 3200, // ms at speed 1×

  get active()  { return localStorage.getItem('an_active') === '1'; },
  set active(v) { localStorage.setItem('an_active', v ? '1' : '0'); },

  get speed()   { return parseFloat(localStorage.getItem('an_speed') || '1'); },
  set speed(v)  { localStorage.setItem('an_speed', String(v)); },

  get paused()  { return localStorage.getItem('an_paused') === '1'; },
  set paused(v) { localStorage.setItem('an_paused', v ? '1' : '0'); },

  currentIndex() {
    const file = location.pathname.split('/').pop() || 'index.html';
    return this.PAGES.findIndex(p => p.file === file);
  },

  nextPage() {
    const next = (this.currentIndex() + 1) % this.PAGES.length;
    return this.PAGES[next];
  },

  isLastPage() {
    return this.currentIndex() === this.PAGES.length - 1;
  },
};

// ── State ──
let navTimeout = null;
let barInterval = null;
let stopped = false;

// ── DOM helpers ──
function q(id) { return document.getElementById(id); }

function fadeOut(el, cb) {
  el.style.transition = 'opacity .28s';
  el.style.opacity = '0';
  setTimeout(() => { if (cb) cb(); }, 300);
}

// ── Build HUD dots ──
function buildDots() {
  const wrap = q('hud-dots');
  if (!wrap) return;
  wrap.innerHTML = '';
  const cur = AN.currentIndex();
  AN.PAGES.forEach((p, i) => {
    const d = document.createElement('div');
    d.className = 'hud-dot' + (i === cur ? ' active' : i < cur ? ' visited' : '');
    d.title = p.name;
    wrap.appendChild(d);
  });
}

// ── Show HUD ──
function showHUD() {
  const hud = q('hud');
  if (!hud) return;
  hud.style.display = 'flex';
  buildDots();
  if (q('hud-speed-lbl')) q('hud-speed-lbl').textContent = AN.speed + '×';
  if (q('hud-page-name')) q('hud-page-name').textContent = AN.PAGES[AN.currentIndex()].name;
}

// ── Countdown bar ──
function startCountdownBar(duration) {
  const bar = q('hud-bar-fill');
  if (!bar) return;
  bar.style.transition = 'none';
  bar.style.width = '100%';
  // Small delay to let transition reset
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      bar.style.transition = `width ${duration}ms linear`;
      bar.style.width = '0%';
    });
  });

  let remaining = duration;
  const step = 200;
  barInterval = setInterval(() => {
    remaining -= step;
    const secs = Math.ceil(remaining / 1000);
    if (q('hud-countdown')) q('hud-countdown').textContent = `→ ${AN.nextPage().name} dans ${Math.max(secs,0)}s`;
    if (remaining <= 0) clearInterval(barInterval);
  }, step);
}

// ── Navigate to next page ──
function goNext() {
  if (stopped || !AN.active) return;
  const next = AN.nextPage();
  if (AN.isLastPage()) {
    // Show loop toast briefly, then go
    const lt = q('loop-toast');
    if (lt) {
      lt.style.display = 'block';
      lt.style.opacity = '1';
    }
    setTimeout(() => location.href = next.file, 800);
  } else {
    location.href = next.file;
  }
}

// ── Stop auto nav ──
function stopAutoNav() {
  if (stopped) return;
  stopped = true;
  AN.active = false;
  clearTimeout(navTimeout);
  clearInterval(barInterval);

  const hud = q('hud');
  if (hud) fadeOut(hud, () => { hud.style.display = 'none'; });

  const pb = q('paused-banner');
  if (pb) {
    pb.style.display = 'flex';
    pb.style.opacity = '1';
    setTimeout(() => {
      fadeOut(pb, () => { pb.style.display = 'none'; pb.style.opacity = '1'; pb.style.transition = ''; });
    }, 2800);
  }
}

// ── Init on each page ──
function initAutoNav() {
  buildDots();

  if (!AN.active) return;

  showHUD();
  stopped = false;

  const pause = Math.max(AN.BASE_PAUSE / AN.speed, 500);

  // Update countdown label immediately
  const secs = Math.ceil(pause / 1000);
  if (q('hud-countdown')) q('hud-countdown').textContent = `→ ${AN.nextPage().name} dans ${secs}s`;

  startCountdownBar(pause);
  navTimeout = setTimeout(() => goNext(), pause);

  // Block interactions (touch/scroll/key/click)
  const blocker = (e) => {
    if (!AN.active) return;
    const hud = q('hud');
    if (hud && hud.contains(e.target)) return;
    stopAutoNav();
  };
  ['touchstart','mousedown','wheel','keydown'].forEach(ev => {
    window.addEventListener(ev, blocker, { passive: true, once: false });
  });
}

// ── Expose globally ──
window.AN = AN;
window.stopAutoNav = stopAutoNav;
window.initAutoNav = initAutoNav;
window.fadeOut = fadeOut;

// ── Speed selection helper ──
function setupSpeedToast() {
  const overlay = q('speed-overlay');
  const confirm = q('speed-confirm');
  if (!overlay || !confirm) return;

  let selected = null;

  document.querySelectorAll('.speed-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selected = parseFloat(btn.dataset.speed);
      confirm.disabled = false;
      confirm.textContent = `Démarrer à ${selected}× →`;
    });
  });

  confirm.addEventListener('click', () => {
    if (!selected) return;
    AN.speed = selected;
    AN.active = true;
    fadeOut(overlay, () => { overlay.style.display = 'none'; overlay.style.opacity = '1'; });
    initAutoNav();
  });
}
